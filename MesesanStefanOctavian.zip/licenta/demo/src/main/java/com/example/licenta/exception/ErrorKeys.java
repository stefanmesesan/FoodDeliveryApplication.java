package com.example.licenta.exception;

public enum ErrorKeys {
    ALREADY_EXISTS,
    INVALID_STATUS,
    INVALID_RATING,
    NOT_FOUND,
    UNAUTHORIZED,
    USER_NOT_FOUND
}
