package com.example.licenta.model;

public enum UserRole {
    ADMIN,
    CUSTOMER,
    RESTAURANT_OPERATOR,
    DELIVERY_GUY
}
