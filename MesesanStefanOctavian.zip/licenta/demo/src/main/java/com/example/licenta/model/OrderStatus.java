package com.example.licenta.model;

public enum OrderStatus {
    NEW,
    ORDER_RECEIVED,
    ORDER_CANCELED,
    ON_ITS_WAY,
    DELIVERED
}
