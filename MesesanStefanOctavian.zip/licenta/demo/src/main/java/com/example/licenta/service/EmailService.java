package com.example.licenta.service;

import com.example.licenta.model.EmailDetails;

public interface EmailService {

    String sendSimpleMail(EmailDetails details);

}
