package com.example.licenta.service;

import java.util.UUID;

public interface OrderItemService {
    void deleteByMenuItem(UUID id);
}
