package com.example.licenta.security.token;

public enum TokenType {
    BEARER
}