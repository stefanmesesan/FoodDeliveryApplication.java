export default function Home() {
    return (
        <div className="previous">
            <a href="/restaurants">Home</a>
        </div>
    );
}
