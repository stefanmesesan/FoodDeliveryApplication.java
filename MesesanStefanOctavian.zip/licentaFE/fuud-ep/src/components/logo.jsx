export default function Logo() {
    return (
        <div className="logo">
            <a href={`/restaurants`}>
                <h1 className="nav-bar-logo">FUUD|EP</h1>
            </a>
        </div>
    );
}
